# Missao-fossa-das-marianas.
Explore as profundezas da Fossa das Marianas neste desafio arcade em Python. Sobreviva à pressão e aos obstáculos enquanto o oceano escurece!
